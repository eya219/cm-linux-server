#! /bin/sh

PRG=`which "$0"`
DIR=`dirname "$PRG"`

java -cp "${DIR}/cm-install.jar" se.nexus.cm.install.prepare.server.ServerPreInstallation $*
